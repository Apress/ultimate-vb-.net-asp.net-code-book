This ZIP file contains the .NET Application Updater component sample.  For more information on this component see the ".NET Application Updater.doc" file in the Docs directory.

ZIP CONTENTS:

-> AppStart - THe AppStart.exe project.
-> AppUpdater - The .NET Application Updater component project.
-> AppUpdaterKeys - The assembly used to hold valid application keys.
-> Docs - Documenation for the .NET Application Updater component.
-> Samples - Files for the SampleApp walkthrough.
  -> SampleApp - Sample described in detail in ".Net Application Updater.doc".
  -> AdvancedSample - Illustrates advances uses of the .Net Application Updater component.
  -> SimpleSample - Illustrates the most basic use of the .NET Application Updater component.


