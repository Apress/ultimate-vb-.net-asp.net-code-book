imports System.Data
imports System.Data.SqlClient 
imports System.Messaging
imports System.IO
 
Public Class Form1
    Inherits System.Windows.Forms.Form
    Public oDataSet As Object
    Public oQueue As New MessageQueue(".\Private$\MyQueue")    
    Public oConnection As New SQLConnection()
    
#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents DataGrid1 As System.Windows.Forms.DataGrid
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents btnGetFromDatabase As System.Windows.Forms.Button
    Friend WithEvents btnSendToQueue As System.Windows.Forms.Button
    Friend WithEvents btnViewMessage As System.Windows.Forms.Button
    Friend WithEvents btnGetFromQueue As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.DataGrid1 = New System.Windows.Forms.DataGrid()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.btnGetFromDatabase = New System.Windows.Forms.Button()
        Me.btnSendToQueue = New System.Windows.Forms.Button()
        Me.btnViewMessage = New System.Windows.Forms.Button()
        Me.btnGetFromQueue = New System.Windows.Forms.Button()
        CType(Me.DataGrid1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'DataGrid1
        '
        Me.DataGrid1.Anchor = ((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right)
        Me.DataGrid1.CaptionFont = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DataGrid1.DataMember = ""
        Me.DataGrid1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DataGrid1.HeaderFont = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DataGrid1.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.DataGrid1.Location = New System.Drawing.Point(8, 96)
        Me.DataGrid1.Name = "DataGrid1"
        Me.DataGrid1.PreferredColumnWidth = 200
        Me.DataGrid1.PreferredRowHeight = 30
        Me.DataGrid1.Size = New System.Drawing.Size(768, 224)
        Me.DataGrid1.TabIndex = 0
        '
        'TextBox1
        '
        Me.TextBox1.Anchor = (((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right)
        Me.TextBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox1.Location = New System.Drawing.Point(8, 336)
        Me.TextBox1.Multiline = True
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.TextBox1.Size = New System.Drawing.Size(768, 184)
        Me.TextBox1.TabIndex = 1
        Me.TextBox1.Text = ""
        '
        'btnGetFromDatabase
        '
        Me.btnGetFromDatabase.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnGetFromDatabase.Location = New System.Drawing.Point(24, 8)
        Me.btnGetFromDatabase.Name = "btnGetFromDatabase"
        Me.btnGetFromDatabase.Size = New System.Drawing.Size(336, 32)
        Me.btnGetFromDatabase.TabIndex = 2
        Me.btnGetFromDatabase.Text = "Get Customers From Database"
        '
        'btnSendToQueue
        '
        Me.btnSendToQueue.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSendToQueue.Location = New System.Drawing.Point(24, 48)
        Me.btnSendToQueue.Name = "btnSendToQueue"
        Me.btnSendToQueue.Size = New System.Drawing.Size(336, 32)
        Me.btnSendToQueue.TabIndex = 3
        Me.btnSendToQueue.Text = "Send Customers To Queue"
        '
        'btnViewMessage
        '
        Me.btnViewMessage.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnViewMessage.Location = New System.Drawing.Point(376, 8)
        Me.btnViewMessage.Name = "btnViewMessage"
        Me.btnViewMessage.Size = New System.Drawing.Size(336, 32)
        Me.btnViewMessage.TabIndex = 4
        Me.btnViewMessage.Text = "View Queue Message"
        '
        'btnGetFromQueue
        '
        Me.btnGetFromQueue.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnGetFromQueue.Location = New System.Drawing.Point(376, 48)
        Me.btnGetFromQueue.Name = "btnGetFromQueue"
        Me.btnGetFromQueue.Size = New System.Drawing.Size(336, 32)
        Me.btnGetFromQueue.TabIndex = 5
        Me.btnGetFromQueue.Text = "Get Customers From Queue"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(784, 542)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnGetFromQueue, Me.btnViewMessage, Me.btnSendToQueue, Me.btnGetFromDatabase, Me.TextBox1, Me.DataGrid1})
        Me.Name = "Form1"
        Me.Text = "MSMQ Sample"
        CType(Me.DataGrid1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region
'--*****************************************************
'-- Retrieves the Customer DataSet from SQL-Server
'--*****************************************************
Protected Function GetCustomersFromDatabase() as Boolean
'--*****************************************************
    Dim bRetVal As Boolean
    Dim sSQLText as String = "SELECT * From Customers"
    
    Me.oDataSet = New DataSet()
    
    Try
        If Me.OpenConnection() Then
            Dim oAdapter As New SqlDataAdapter(sSQLText,Me.oConnection)
            oAdapter.Fill(Me.oDataSet)

            oDataSet.Tables(0).TableName = "Customers"
            oDataSet.DataSetName = "CustomerData"
            bRetVal = True
        End If
    
    Catch
        Me.TextBox1.Text = "Could not retrieve data from database. Check your query statement."
        bRetVal = False

    Finally
        Me.CloseConnection()
        
    End Try
    Return bRetVal
End Function        

'--***********************************************
'-- Sends the Customer DataSet _directly_ to MSMQ (Yippie!)
'--***********************************************
Protected Sub SendCustomersToQueue() 
'--***********************************************
   Try
        If Me.oDataSet.Tables("Customers").DefaultView.Count > 0 Then
                
            oQueue.Send(Me.oDataSet, "My Customer Dataset")
        
            Me.TextBox1.Text = "DataSet sucessfully sent to " + oQueue.Label 
        Else
            Me.TextBox1.Text = "There are no customers in your DataSet to send."
        End if
   
    Catch e as Exception
        Me.TextBox1.Text = "There was a problem sending your data. You may need to retrieve the customer data first."

    End Try
End Sub

'--************************************************
'-- Just view the message body as a text stream 
'--   since it is just XML. 
'-- This doesn't pull the message off of the queue, 
'--   it simply peeks at it.
'--************************************************
Protected Sub PeekMessageOnQueue()
'--************************************************       
    Try
        Dim myMessage As Message = oQueue.Peek(New TimeSpan(1))
        
        Dim sr as New StreamReader(myMessage.BodyStream)
        Me.TextBox1.Text = sr.ReadToEnd()
                      
    Catch e as Exception
        Me.TextBox1.Text = "There are no messages on the queue."
        
    End Try

End Sub

'--************************************************
'-- Retrieve the DataSet from MSMQ _directly_ into 
'--    the DataSet object (la la laaaa!)
'--************************************************
Protected Function GetCustomersFromQueue() as Boolean
'--************************************************
    Dim bRetVal As Boolean = True
   
    Try
        Dim myMessage As Message = oQueue.Receive(New TimeSpan(1))
        Me.oDataSet = CType(myMessage.Body, DataSet)
        
    Catch e as Exception
        Me.TextBox1.Text = "There are no messages on the queue."
        bRetVal = False
    End Try
    
    Return bRetVal

End Function

Protected Function OpenConnection() As Boolean
        Dim bRetVal As Boolean
        bRetVal = True
                 
        With Me.oConnection
        
        Try    
            If .ConnectionString = "" Then
                .ConnectionString = "User ID=sa;Password=;Initial Catalog=Northwind;Data Source=MyComputer"
            End If

            If .State = ConnectionState.Closed Then
                .Open()
            End If

        Catch e as Exception
            Me.TextBox1.Text = "Could not connect to database! Make sure your connection string is coolio."
        
        Finally
            If .State <> ConnectionState.Open Then
                 bRetVal = False
            End If
        End try

        End With

        Return bRetVal
    End Function

    Protected Function CloseConnection() As Boolean
        Dim bRetVal As Boolean
        bRetVal = True
        
        With Me.oConnection
            Try

                If .State = ConnectionState.Open Then
                    .Close()

                End If
            Catch
            Finally    
                If .State <> ConnectionState.Closed Then
                    bRetVal = False
                End If
            End Try

        End With
        
        Return bRetVal
    End Function

    
   
    Private Sub btnGetFromDatabase_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGetFromDatabase.Click
        '-- Retrieve Customer DataSet from database and display in the grid
        If Me.GetCustomersFromDatabase() Then
            Me.DataGrid1.DataSource = Me.oDataSet.Tables("Customers")   
            Me.DataGrid1.CaptionText = "Customers from Northwind Database"
            Me.DataGrid1.CaptionBackColor  = Color.Aquamarine 

        End if
            
    End Sub


    Private Sub btnGetFromQueue_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGetFromQueue.Click
        '-- Retrieve Customer DataSet from MSMQ and display in the grid
        If Me.GetCustomersFromQueue() Then
            Me.DataGrid1.DataSource = Me.oDataSet.Tables("Customers")   
            Me.DataGrid1.CaptionText = "Customers from " + oQueue.Label 
            Me.DataGrid1.CaptionBackColor  = Color.Salmon

        End if
    End Sub

    Private Sub btnSendToQueue_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSendToQueue.Click

        Me.SendCustomersToQueue()
                            
    End Sub

    Private Sub btnViewMessage_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnViewMessage.Click

        Me.PeekMessageOnQueue() 
                    
    End Sub

    
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class
